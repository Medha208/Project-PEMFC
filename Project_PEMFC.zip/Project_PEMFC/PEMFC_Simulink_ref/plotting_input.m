plot(InputI_stdy_ideal(:,2))
plot(InputI_stdy(:,2))
plot(InputI_dynshrt4(:,2))