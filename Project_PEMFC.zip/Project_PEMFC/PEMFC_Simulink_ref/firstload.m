%LOAD DATA


%   I= [[0,0];InputI_stdy];
% 
%   save("InputI_stdy.mat","I",'-v4');

  %load('InputI_stdy');



  % load('InputI_stdy_ideal');
  % I= InputI_stdy_ideal;
  % 
  % save("InputI_stdy_ideal.mat","I",'-v4');



  load('InputI_dynshrt4.mat');
  I= [[0,0];InputI_dynshrt4];

  save("InputI_dynshrt4.mat","I",'-v4');







