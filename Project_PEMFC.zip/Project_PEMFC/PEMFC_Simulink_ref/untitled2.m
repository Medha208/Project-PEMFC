save("InputI_stdy_ideal.mat", "InputI_stdy_ideal",'-v4');
save("InputI_stdy.mat", "InputI_stdy",'-v4');
save("InputI_dynshrt4.mat", "InputI_dynshrt4",'-v4');